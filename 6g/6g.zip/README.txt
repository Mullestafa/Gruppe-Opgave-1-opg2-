Jákup Lützen, Niels Dreesen, Mustafa Hekmat Al Abdelamir
November 5. 2022

Once in the root directory of the program it can be run with the command:
dotnet run \Program.fsx
Numerous test results to check the validity of the program will be printed. When the GUI has lunched,
it is possible to control the game with the arrow keys. Press the arrowkey in the direction you want to
tilt the pieces.